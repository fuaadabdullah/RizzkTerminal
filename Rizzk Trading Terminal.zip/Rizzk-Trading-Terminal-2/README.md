# Rizzk Trading Terminal

Single-file Streamlit terminal with: prices, RSI/SMA, SMA-cross backtester, Yahoo screener,
trading journal (JSON), market clock, Alpha Vantage news, and an AI assistant (GPT-3.5 turbo).

## Quickstart (Windows, PowerShell)
```powershell
cd "C:\Users\YOURNAME\Rizzk Trading Terminal\Rizzk-Trading-Terminal-2"
python -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
streamlit run rizzk_pro.py
```

### Env (optional but recommended)
```powershell
setx OPENAI_API_KEY "sk-your-real-openai-key"
setx ALPHAVANTAGE_API_KEY "your-alpha-vantage-key"
```
Or copy `.env.example` to `.env` and fill keys. You can also paste keys into the app sidebar.
